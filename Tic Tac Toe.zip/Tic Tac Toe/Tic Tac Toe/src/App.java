import java.util.Scanner;

public class App {

    private static char[][] board = {
        {' ', ' ', ' '},
        {' ', ' ', ' '},
        {' ', ' ', ' '}
    };

    private static char currentPlayer = '*';

    private static void printBoard() {
        System.out.println("  1 2 3");
        for (int i = 0; i < 3; i++) {
            System.out.print((i + 1) + " ");
            for (int j = 0; j < 3; j++) {
                System.out.print(board[i][j]);
                if (j < 2) System.out.print("|");
            }
            System.out.println();
            if (i < 2) System.out.println("  -----");
        }
    }

    private static boolean isValidMove(int row, int col) {
        return row >= 0 && row < 3 && col >= 0 && col < 3 && board[row][col] == ' ';
    }

    private static void makeMove(int row, int col) {
        board[row][col] = currentPlayer;
    }

    private static void switchPlayer() {
        currentPlayer = (currentPlayer == '*') ? 'o' : '*';
    }

    private static boolean checkWinner() {
        // Check rows and columns
        for (int i = 0; i < 3; i++) {
            if ((board[i][0] == currentPlayer && board[i][1] == currentPlayer && board[i][2] == currentPlayer) || (board[0][i] == currentPlayer && board[1][i] == currentPlayer && board[2][i] == currentPlayer)) {
                return true;
            }
        }

        // Check diagonals
        if ((board[0][0] == currentPlayer && board[1][1] == currentPlayer && board[2][2] == currentPlayer) || (board[0][2] == currentPlayer && board[1][1] == currentPlayer && board[2][0] == currentPlayer)) {
            return true;
        }

        return false;
    }

    private static boolean isBoardFull() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j] == ' ') {
                    return false;
                }
            }
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean gameIsRunning = true;
        System.out.println("Welcome to Tic Tac Toe!");
        printBoard();

        while (gameIsRunning) {
            try {
                System.out.println("Player " + currentPlayer + ", it's your turn.");
                System.out.print("Enter row (1-3): ");
                int row = sc.nextInt() - 1;
                System.out.print("Enter column (1-3): ");
                int col = sc.nextInt() - 1;

                if (isValidMove(row, col)) {
                    makeMove(row, col);
                    printBoard();

                    if (checkWinner()) {
                        System.out.println("Player " + currentPlayer + " wins!");
                        gameIsRunning = false;
                    } else if (isBoardFull()) {
                        System.out.println("It's a draw!");
                        gameIsRunning = false;
                    } else {
                        switchPlayer();
                    }
                } else {
                    System.out.println("Invalid move. Try again.");
                }
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter numbers between 1 and 3.");
                sc.nextLine(); // Clear the invalid input
            }
        }

        sc.close();
    }
}