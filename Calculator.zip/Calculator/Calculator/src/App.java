import java.util.Scanner;
class Calculator {
    public float add(float a, float b) {
        return a + b;
    }
    public float sub(float a, float b) {
        return a - b;
    }
    public float mul(float a, float b) {
        return a * b;
    }
    public float div(float a, float b) {
        return a / b;
    }
    public float mod(float a, float b) {
        return a % b;
    }
    public float pow(float a, float b) {
        return (float) Math.pow(a, b);
    }
    public float sqrt(float a) {
        return (float) Math.sqrt(a);
    }
}
public class App {
    public static void main(String[] args) {
        Calculator calculator = new Calculator();
        Scanner scanner = new Scanner(System.in);
        System.out.println("List of operations: ");
        System.out.println("1. '+' for addition\n2. '-' for subtraction\n3. '*' for multiplication\n4. '/' for division\n5. '%' for modulo\n6. '^' for power\n7. 'sqrt' for square root");
        System.out.println("Enter the operation: ");
        String operation = scanner.next();
        System.out.println("Enter the first number: ");
        float a = scanner.nextFloat();
        System.out.println("Enter the second number: ");
        float b = scanner.nextFloat();
        switch (operation) {
            case "+":
                System.out.println("Result: " + calculator.add(a, b));
                break;
            case "-":
                System.out.println("Result: " + calculator.sub(a, b));
                break;
            case "*":
                System.out.println("Result: " + calculator.mul(a, b));
                break;
            case "/":
                System.out.println("Result: " + calculator.div(a, b));
                break;
            case "%":
                System.out.println("Result: " + calculator.mod(a, b));
                break;
            case "^":
                System.out.println("Result: " + calculator.pow(a, b));
                break;
            case "sqrt":
                System.out.println("Result: " + calculator.sqrt(a));
                break;
            default:
                System.out.println("Invalid operation");
        }  
    }
}
